<?php
	include('google_login.php');
?>

<!DOCTYPE html>
<html>
 <head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Login Google PHP</title>
  <meta content='width=device-width, initial-scale=1, maximum-scale=1' name='viewport'/>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />
  
 </head>
 <body>
 	<div class="container">
   	<br />
   	<h2 align="center">PHP Login</h2>
   	<br />
   	<div class="panel panel-default">
   	<h2>Berhasil Login</h2>;
   	<h3><a href="logout.php">Logout</h3></div>;
   	</div>
  </div>
 </body>
</html>