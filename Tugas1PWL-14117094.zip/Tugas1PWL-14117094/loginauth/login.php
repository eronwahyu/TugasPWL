<?php 
session_start();
 
// menghubungkan koneksi
include 'dbconnect.php';
 

$username = $_POST['username'];
$password = $_POST['password'];
 
// Menyimpan data inputan username dan pass
$data = mysqli_query($koneksi,"select * from login where username='$username' and password='$password'");
 
// seleksi data inputan yang sama
$cek = mysqli_num_rows($data);
 
	$_SESSION['username'] = $username;
	$_SESSION['status'] = "login";
	header("location:awal.php");
?>